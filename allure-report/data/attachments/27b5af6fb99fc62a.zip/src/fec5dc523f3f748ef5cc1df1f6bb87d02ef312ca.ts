import { test, expect } from "../../../fixtures/page-fixture";
import { verifyImages } from "../../../utils/ImageHelper";

test.describe("Dashboard Feature", () => {

  test.beforeEach(async ({ page }) => {
    await page.goto("/");
  });

  test.describe("Banner", () => {
    test("D_09: Kiểm tra slider banner hiển thị hình ảnh", async ({ page }) => {
      const bannerImg = page.locator('.slick-slider img, .carousel img').first();
      await expect(bannerImg, "Kiểm tra banner hiển thị").toBeVisible();
      await verifyImages(page, bannerImg);
    });
  });

  test.describe("Movie Search (Quick Booking Bar)", () => {
    test("D_10: Kiểm tra dropdown Phim hiển thị danh sách phim", async ({ homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      await expect(searchComp.optionList.first()).toBeVisible();
    });

    test("D_11: Tìm kiếm bằng chữ cái tên phim trong danh sách phim", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      await page.keyboard.type("Avatar");
      await page.waitForTimeout(500);
      await expect(searchComp.optionList.first()).toBeVisible();
    });

    test("D_12: Kiểm tra dropdown Rạp hiển thị danh sách rạp khi chưa chọn Phim", async ({ homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlRap);
      await expect(searchComp.optionList).not.toBeVisible();
    });

    test("D_13: Kiểm tra dropdown Rạp hiển thị danh sách rạp khi đã chọn Phim", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      if (await searchComp.optionList.first().isVisible()) {
        await searchComp.optionList.first().click();
        await searchComp.clickDropdown(searchComp.ddlRap);
        await expect(searchComp.optionList.first()).toBeVisible();
      }
    });

    test("D_14: Kiểm tra dropdown Ngày giờ chiếu hiển thị các suất chiếu khi chưa chọn Phim và Rạp", async ({ homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlNgayGioChieu);
      await expect(searchComp.optionList).not.toBeVisible();
    });

    test("D_15: Kiểm tra dropdown Ngày giờ chiếu hiển thị các suất chiếu đã chọn Phim và Rạp", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      await searchComp.optionList.first().click();
      await searchComp.clickDropdown(searchComp.ddlRap);
      await searchComp.optionList.first().click();
      await searchComp.clickDropdown(searchComp.ddlNgayGioChieu);
      await expect(searchComp.optionList.first(), "Kỳ vọng hiển thị suất chiếu khi chọn Phim và Rạp").toBeVisible();
    });

    test("D_16: Kiểm tra dropdown Ngày giờ chiếu hiển thị các suất chiếu khi chỉ chọn Phim", async ({ homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      if (await searchComp.optionList.first().isVisible()) {
        await searchComp.optionList.first().click();
        await searchComp.clickDropdown(searchComp.ddlNgayGioChieu);
        await expect(searchComp.optionList).not.toBeVisible();
      }
    });

    test("D_17: Click nút 'Mua vé ngay' khi chưa chọn Phim + Rạp + Ngày giờ chiếu", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickMuaVeNgay();
    });

    test("D_18: Click nút 'Mua vé ngay' khi chỉ chọn Phim", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      if (await searchComp.optionList.first().isVisible()) {
        await searchComp.optionList.first().click();
        await searchComp.clickMuaVeNgay();
      }
    });

    test("D_19: Click nút 'Mua vé ngay' khi chỉ chọn Phim + Rạp", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      if (await searchComp.optionList.first().isVisible()) {
        await searchComp.optionList.first().click();
        await searchComp.clickDropdown(searchComp.ddlRap);
        if (await searchComp.optionList.first().isVisible()) {
          await searchComp.optionList.first().click();
          await searchComp.clickMuaVeNgay();
        }
      }
    });

    test("D_20: Kiểm tra tìm kiếm suất chiếu với đầy đủ thông tin", async ({ page, homePage }) => {
      const searchComp = homePage.getMovieSearchComponent();
      await searchComp.clickDropdown(searchComp.ddlPhim);
      if (await searchComp.optionList.first().isVisible()) {
        await searchComp.optionList.first().click();
        await searchComp.clickDropdown(searchComp.ddlRap);
        if (await searchComp.optionList.first().isVisible()) {
          await searchComp.optionList.first().click();
          await searchComp.clickDropdown(searchComp.ddlNgayGioChieu);
          if (await searchComp.optionList.first().isVisible()) {
            await searchComp.optionList.first().click();
            await searchComp.clickMuaVeNgay();
          }
        }
      }
    });
  });

  test.describe("Movie Listing", () => {
    test("D_21: Kiểm tra danh sách phim trên trang chủ được hiển thị", async ({ page, homePage }) => {
      const movieListing = homePage.getMovieListingComponent();
      await expect(movieListing.movieListContainer).toBeVisible();
      const firstPoster = movieListing.movieCards.first().locator('img').first();
      await expect(firstPoster).toBeVisible();
      await verifyImages(page, firstPoster);
    });

    test("D_22: Kiểm tra pagination của danh sách phim", async ({ homePage }) => {
      const movieListing = homePage.getMovieListingComponent();
      await movieListing.movieCards.first().waitFor();
      if (await movieListing.nextPaginationBtn.isVisible()) {
          await movieListing.clickNextPagination();
          await expect(movieListing.activePaginationBtn).toHaveText(/2|.*/);
      }
    });

    test("D_23: Kiểm tra thông tin hiển thị trên thẻ phim", async ({ page, homePage }) => {
      const movieListing = homePage.getMovieListingComponent();
      const firstCard = await movieListing.getMovieCardByIndex(0);
      const poster = await movieListing.getMoviePoster(firstCard);
      await expect(poster).toBeVisible();
      await verifyImages(page, poster);
    });

    test("D_24: Nhãn phân loại độ tuổi", async ({ homePage }) => {
      const movieListing = homePage.getMovieListingComponent();
      const firstCard = await movieListing.getMovieCardByIndex(0);
      const ageLabel = await movieListing.getMovieAgeLabel(firstCard);
      if (await ageLabel.isVisible()) {
        await expect(ageLabel).toBeVisible();
      }
    });

    test("D_25: Hiển thị nút 'Play' và 'Mua vé' khi rê chuột", async ({ homePage }) => {
      const movieListing = homePage.getMovieListingComponent();
      const firstCard = await movieListing.getMovieCardByIndex(0);
      await firstCard.hover();
      await expect(await movieListing.getMoviePlayBtn(firstCard)).toBeVisible();
      await expect(await movieListing.getMovieBuyTicketBtn(firstCard)).toBeVisible();
    });
  });

  test.describe("Cinema List", () => {
    test("D_31: Kiểm tra danh sách rạp được hiển thị", async ({ homePage }) => {
      const cinemaList = homePage.getCinemaListComponent();
      await expect(cinemaList.cinemaListContainer).toBeVisible();
      await expect(await cinemaList.getCinemaSystemLogos()).not.toHaveCount(0);
    });

    test("D_32: Kiểm tra hiển thị nội dung danh sách rạp phim", async ({ page, homePage }) => {
      const cinemaList = homePage.getCinemaListComponent();
      const cinemaLogo = (await cinemaList.getCinemaSystemLogos()).first();
      await expect(cinemaLogo).toBeVisible();
      await verifyImages(page, cinemaLogo);
    });

    test("D_33: Chọn một rạp để xem lịch chiếu", async ({ homePage }) => {
      const cinemaList = homePage.getCinemaListComponent();
      if (await cinemaList.cinemaSystemLogos.count() > 1) {
          await cinemaList.clickCinemaSystemByIndex(1);
          await expect(cinemaList.showTimesList).toBeVisible();
      }
    });
  });

  test.describe("UI / Responsive & Loading", () => {
    test("D_27: Kiểm tra giao diện trên màn hình desktop", async ({ page }) => {
      await page.setViewportSize({ width: 1920, height: 1080 });
      await page.goto("/");
      await expect(page.locator('body')).toBeVisible();
    });

    test("D_28: Kiểm tra responsive trên màn hình nhỏ", async ({ page }) => {
      await page.setViewportSize({ width: 375, height: 667 });
      await page.goto("/");
      await expect(page.locator('body')).toBeVisible();
    });

    test("D_29: Kiểm tra trạng thái loading khi tải dữ liệu phim", async ({ page }) => {
      await page.route('**/api/QuanLyPhim/**', async route => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        await route.continue();
      });
      await page.goto("/");
      await expect(page.locator('body')).toBeVisible();
    });

    test("D_30: Kiểm tra giao diện khi API lấy danh sách phim bị lỗi", async ({ page }) => {
      await page.route('**/api/QuanLyPhim/**', async route => {
        await route.fulfill({ status: 500, body: 'Internal Server Error' });
      });
      await page.goto("/");
      await expect(page.locator('body')).toBeVisible();
    });
  });
});
