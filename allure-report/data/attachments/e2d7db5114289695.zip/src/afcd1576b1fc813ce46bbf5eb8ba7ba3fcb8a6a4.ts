import { Locator, Page } from "@playwright/test";
import { BasePage } from "../BasePage";
import { TimeOutConstants } from "../../constants/TimeOutConstants";

export class MovieSearchComponent extends BasePage {
    readonly ddlPhim: Locator;
    readonly ddlRap: Locator;
    readonly ddlNgayGioChieu: Locator;
    readonly btnMuaVeNgay: Locator;
    
    // For handling dropdown selections
    readonly optionList: Locator;
    readonly searchInput: Locator;

    //
    readonly btnNextPagination: Locator;
    readonly movieListContainer: Locator;

    constructor(page: Page) {
        super(page);
        this.ddlPhim = page.locator('text=Phim').first();
        this.ddlRap = page.locator('text=Rạp').first();
        this.ddlNgayGioChieu = page.locator('text=Ngày giờ chiếu').first();
        this.btnMuaVeNgay = page.getByRole("button", {name: "MUA VÉ NGAY", exact: false});
        this.optionList = page.locator('.dropdown-menu, .ant-select-dropdown, ul[role="listbox"], ul[role="menu"]').locator('li, .ant-select-item, [role="option"], .MuiMenuItem-root');
        this.searchInput = page.locator('input[type="text"].ant-select-selection-search-input, input[placeholder*="Phim"]');
        this.btnNextPagination = page.locator('div:nth-child(2) > .MuiButtonBase-root.MuiIconButton-root.jss90.jss92');
        this.movieListContainer = page.locator('.jss20');
    }

    async clickDropdown(dropdownLocator: Locator, timeOut: number = TimeOutConstants.TIME_OUT_DEFAULT) {
        await this.click(dropdownLocator, timeOut);
    }

    async selectOption(optionName: string, timeOut: number = TimeOutConstants.TIME_OUT_DEFAULT) {
        const option = this.optionList.filter({ hasText: optionName }).first();
        await this.click(option, timeOut);
    }

    async clickMuaVeNgay(timeOut: number = TimeOutConstants.TIME_OUT_DEFAULT) {
        await this.click(this.btnMuaVeNgay, timeOut);
    }

    async clickNextPagination(timeOut: number = TimeOutConstants.TIME_OUT_DEFAULT) {
        await this.click(this.btnNextPagination, timeOut);
    }

    async clickMovieCardByName(movieName: string, timeOut: number = TimeOutConstants.TIME_OUT_DEFAULT) {
        await this.click(this.movieListContainer,timeOut);
    }
}
